#!/bin/sh

cd /home/stdout
timeout 60 ./stdout